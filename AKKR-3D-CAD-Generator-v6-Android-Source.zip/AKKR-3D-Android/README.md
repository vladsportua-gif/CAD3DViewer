# AKKR 3D CAD Generator 6.0 (Android)

A native offline WebView app for 3D reducer assemblies and CAD file transfer. No PDF, 2D drawing editor, frames or specification UI.

**Source values**: AKKR 2018 practicum, Appendix B, Variant 5. Default gear normal module 3 mm, z1 19, z2 103, center 183 mm, b1 51 mm, b2 46 mm. Others editable including shaft bearing and key sizes.

**On Android**: 3D preview of pinion, gear, shafts with longitudinal keyways, bearings, keys, split housing and curved lid. Exports STL/OBJ (coordinates encoded as nominal mm, note STL is unitless), JSON and CAD ZIP. Shares using native Android chooser (e.g., Telegram). CAD ZIP includes a separate STL for each part, machine-readable bounding boxes, CSV placement, parametric JSON, and FreeCAD Desktop macro.

**On Desktop**: Run `GENERATE_STEP_FreeCAD.FCMacro` using FreeCAD. It computes B-Rep solids from the nominal dimensions and exports separated `*.step` files, full assembly STEP, native `*.FCStd`, and a CSV dimension check to `AKKR_STEP_mm`. Open STEP as CAD solids in Inventor/SolidWorks; mm is the STEP length unit. STEP geometry is not a native Inventor/SolidWorks feature tree and should be checked before final engineering use.

**Limitations**: Tooth outline uses sampled involute flanks with approximate root fillets and no shift; missing housing details are schematic. Default angular pressure angle 20° is an assumption. Some mesh shells are not watertight for 3D printing. Exact manufacturing drawings, fits, tolerance, and physical testing are outside the app.

Build `:app:assembleDebug` on Android SDK API 35, Gradle 8.10.2 and Java 17.
