'use strict';
// Native Android exports binary STL meshes; STEP B-Rep exports run offline in FreeCAD Desktop.
// STEP/CAD geometry is reconstructed directly from nominal mm parameters, NOT a scaled mesh.
function freeCADMacroText(){
const content=String.raw`# -*- coding: utf-8 -*-
# AKKR 3D CAD 6.0 - FreeCAD DESKTOP macro, coordinates and dimensions in millimetres.
# No third-party dependencies. Execute with FreeCAD GUI: Macro > Macros > Execute.
# Generates parametric-source B-Rep components and separate mm STEP parts for Inventor/SolidWorks.
# DISCLAIMER: actual fits, hob/tool root fillets, strength, heat treatment, industrial fasteners,
# bearing series and missing housing sizes require independent design verification.
import FreeCAD as App
import Part, math, os, json, traceback
from FreeCAD import Vector as V
cfg=json.loads(__CONFIG_LITERAL__)
p=cfg['params']; S=cfg['shafts']; sh=cfg['shell']
m=float(p['m']); z1=int(p['z1']); z2=int(p['z2']); alpha=float(p['alpha'])
aw=m*(z1+z2)/2.0; output=os.path.join(os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.path.expanduser('~'),'AKKR_STEP_mm')
if not os.path.isdir(output): os.makedirs(output)
doc=App.newDocument('AKKR_3D_CAD_mm'); components=[]
def cylinder(r,b,x=0,z=0,zz=None):
    return Part.makeCylinder(float(r),float(b),V(x,0,z),V(0,0,1))
def cut_keyway(shape,x,r,width,depth,z0,length):
    # Keyway extends radially outward (+X), with flat bottom at r - t1.
    cutter=Part.makeBox(float(depth)+3,float(width),float(length),V(float(x+r-depth),-float(width)/2.,float(z0)))
    return shape.cut(cutter)
def add(name, shape, color=(0.75,0.79,0.83)):
    if shape.isNull() or not shape.isValid() or shape.Volume <= 1e-7: raise RuntimeError('Invalid CAD solid: '+name)
    code=name.replace(' ','_').replace('-','_')
    obj=doc.addObject('PartDesign::Feature',code)
    obj.Label=name; obj.Shape=shape
    obj.addProperty('App::PropertyString','LengthUnits','CAD');obj.LengthUnits='mm'
    try: obj.ViewObject.ShapeColor=color
    except: pass
    components.append((code,obj));return obj
def involute(z):
    rp=m*z/2.; rb=rp*math.cos(math.radians(alpha)); ra=rp+m;rf=rp-1.25*m
    def inv(r):
        t=math.sqrt(max(0.,(r/rb)**2-1.));return t-math.atan(t)
    def half(r): return math.pi/(2*z)+inv(rp)-inv(max(rb,r))
    low=max(rb,rf);points=[];station_count=16;tip_count=6
    for i in range(z):
        c=i*2*math.pi/z
        def put(r,t): points.append((r*math.cos(c+t),r*math.sin(c+t)))
        put(rf,-half(low))
        if low>rf+1e-6: put(low,-half(low))
        for j in range(1,station_count+1):
            r=low+(ra-low)*j/station_count;put(r,-half(r))
        for j in range(1,tip_count+1): put(ra,-half(ra)+2*half(ra)*j/tip_count)
        for j in range(station_count-1,-1,-1):
            r=low+(ra-low)*j/station_count;put(r,half(r))
        if low>rf+1e-6: put(rf,half(low))
    return points
def extrude_profile(points,b):
    v=[V(a,c,-b/2.) for a,c in points]
    return Part.Face(Part.makePolygon(v+[v[0]])).extrude(V(0,0,b))
def gear(z,b,x,shaft,large=False):
    rp=m*z/2.; root=rp-1.25*m
    tooth=extrude_profile(involute(z),b)
    # Large wheel side recesses: rim (continuous) + thinner web + thicker keyed hub.
    if large:
        hub_radius=max(float(shaft['dk'])/2+10,min(root*.3,float(shaft['dk'])*.95))
        rim_inner=max(hub_radius+7,root-min(max(9.,b*.52),root*.14))
        if rim_inner>hub_radius+4:
            recess=max(2.0,b*.14)
            outer=cylinder(rim_inner,recess,0,-b/2.)
            core=cylinder(hub_radius,recess+2,0,-b/2.-1)
            tooth=tooth.cut(outer.cut(core))
            outer=cylinder(rim_inner,recess,0,b/2.-recess)
            core=cylinder(hub_radius,recess+2,0,b/2.-recess-1)
            tooth=tooth.cut(outer.cut(core))
        boss=cylinder(hub_radius,b+8.,0,-b/2.-4.)
        tooth=tooth.fuse(boss)
        b+=8.
    hole_d=float(shaft['dk']);zmin=-b/2.-5.
    tooth=tooth.cut(cylinder(hole_d/2.,b+10,0,zmin))
    tooth=cut_keyway(tooth,0,hole_d/2.,shaft['keyW'],shaft['keyH']*.56,zmin,b+10)
    tooth.translate(V(x,0,0))
    return tooth

def shaft(s,x):
    L=float(s['alv']);bearing_c=float(s['alo'])/2.;bw=float(s['bp']);seat=float(s['alk'])/2.;shoulder=seat+float(s['alb'])
    bb=bearing_c-bw/2.
    if not (seat<shoulder<bb and bearing_c+bw/2<L/2):raise RuntimeError('Shaft sections overlap; inspect ALK/ALB/ALO/BP/ALV')
    # Join all concentric pieces. Unlike mesh previews this is an exact CAD Boolean union.
    intervals=[(-L/2.,-bearing_c-bw/2,s['dm']),
               (-bearing_c-bw/2,-bb,s['dpv']),
               (-bb,-shoulder,s['dpr']),
               (-shoulder,-seat,s['db']),
               (-seat,seat,s['dk']),
               (seat,shoulder,s['db']),
               (shoulder,bb,s['dpr']),
               (bb,bearing_c+bw/2,s['dpv']),
               (bearing_c+bw/2,L/2,s['dm'])]
    pieces=[cylinder(float(d)/2.,b-a,x,a) for a,b,d in intervals if b-a>1e-6]
    piece=pieces[0]
    for part in pieces[1:]:piece=piece.fuse(part)
    # Central key slot and terminal key slot, as illustrated in the reference shaft.
    keylen=min(s['keyL'],s['alk']-1.)
    piece=cut_keyway(piece,x,s['dk']/2.,s['keyW'],s['keyH']*.56,-keylen/2,keylen)
    end_available=max(0,L/2.-(bearing_c+bw/2.)-2.)
    if end_available>8:
        endlen=min(s['keyL']*.55,end_available)
        piece=cut_keyway(piece,x,s['dm']/2.,min(s['keyW'],s['dm']*.38),min(s['keyH']*.4,s['dm']*.18),-L/2.+1,endlen)
    return piece

def key(s,x):
    r=s['dk']/2.;t=s['keyH']*.56
    return Part.makeBox(s['keyH'],s['keyW'],s['keyL'],V(x+r-t,-s['keyW']/2.,-s['keyL']/2.))

def bearing(x,z,s):
    ri=s['dpv']/2.;ro=s['dpz']/2.;B=s['bp'];h=(ro-ri)
    out=cylinder(ro,B,x,z-B/2.).cut(cylinder(ro-h*.20,B+2,x,z-B/2.-1))
    inner=cylinder(ri+h*.20,B,x,z-B/2.).cut(cylinder(ri,B+2,x,z-B/2.-1))
    balls=[];rad=h*.28;pitch=(ri+ro)/2.
    for i in range(12):
        a=2*math.pi*i/12;balls.append(Part.makeSphere(rad,V(x+pitch*math.cos(a),pitch*math.sin(a),z)))
    return Part.makeCompound([out,inner]+balls)

def envelope():
    tip_big=m*(z2+2)/2.;tip_small=m*(z1+2)/2.
    x0=-tip_small-sh['gapPinion']-sh['wall']-8
    x1=aw+tip_big+sh['gapPinion']+sh['wall']+8
    floor=-tip_big-sh['gapWheel']-sh['wall']
    hz=max(p['b1'],p['b2'])/2.+sh['bearingBoss']/2.+14
    return x0,x1,floor,hz
x0,x1,bottom,hz=envelope();wall=sh['wall'];ridge=m*(z2+2)/2.+sh['gapPinion']+wall

def roof_height(x):
    # Smooth hood: ascending ramp over the small pinion, then a round cover over large wheel.
    cx=aw;r=ridge
    start=cx-r*.86
    if x<start:
        q=max(0.,min(1.,(x-x0)/(start-x0)))
        y_end=r*math.sqrt(1.-.86**2)
        return wall+8+(y_end-wall-8)*q*q*(3-2*q)
    d=(x-cx)/r
    return max(wall+8,r*math.sqrt(max(0.,1-d*d)))

def shell_profile(upper):
    count=170;coords=[]
    for i in range(count+1):
        x=x0+(x1-x0)*i/count
        coords.append((x,roof_height(x)))
    if upper:
        perimeter=[(x0,0),(x1,0)]+list(reversed(coords))
    else:
        perimeter=[(x0,bottom),(x1,bottom),(x1,0),(x0,0)]
    return perimeter

def housing(upper):
    w=wall;bw=2*hz
    shape=extrude_profile(shell_profile(upper),bw)
    if upper:
        # Arched hollow cavity, leaving wall thickness on top, ends and front/back.
        count=140;inner=[]
        for i in range(count+1):
            x=x0+w+(x1-x0-2*w)*i/count
            inner.append((x,max(w*.5,roof_height(x)-w)))
        cut=[(x0+w,-w),(x1-w,-w)]+list(reversed(inner))
        shape=shape.cut(extrude_profile(cut,bw-2*w))
    else:
        cavity=Part.makeBox(x1-x0-2*w,-bottom+w,bw-2*w,V(x0+w,bottom+w,-hz+w))
        shape=shape.cut(cavity)
    # Split-line flanges are in the horizontal plane (Y axis).
    for z in (-hz+sh['flangeWidth']/2.,hz-sh['flangeWidth']/2.):
        y0=0 if upper else -sh['flangeThick']/2.
        flange=Part.makeBox(x1-x0+18,sh['flangeThick']/2,sh['flangeWidth'],V(x0-9,y0,z-sh['flangeWidth']/2.))
        shape=shape.fuse(flange)
    # Two circular half-bearing notches through the end walls, coaxial with shafts (Z).
    for i,cx in enumerate((0.,aw)):
        R=S[i]['dpz']/2.+.35
        # Only the half corresponding to upper/lower split: shared cylindrical bore.
        hole=cylinder(R,2*hz+4,cx,-hz-2)
        shape=shape.cut(hole)
    return shape
try:
    add('01 Pinion',gear(z1,p['b1'],0.,S[0]),(.66,.78,.88))
    add('02 Gear wheel',gear(z2,p['b2'],aw,S[1],True),(.89,.68,.37))
    add('03 Input shaft',shaft(S[0],0.),(.70,.76,.87))
    add('04 Output shaft',shaft(S[1],aw),(.71,.76,.87))
    for i,x in enumerate((0.,aw)):
        for j,sign in enumerate((-1,1)):
            add('0%d Bearing %d%c'%(5+i*2+j,i+1,65+j),bearing(x,sign*S[i]['alo']/2.,S[i]),(.65,.68,.76))
    add('09 Input key',key(S[0],0.),(.80,.75,.56))
    add('10 Output key',key(S[1],aw),(.80,.75,.56))
    add('11 Lower housing',housing(False),(.60,.75,.70))
    add('12 Curved cover',housing(True),(.75,.76,.82))
    bolts=[]
    for x in (x0+16.,(x0+aw)/2.,aw+38.,x1-16.):
        for sign in (-1,1):
            z=sign*(hz+4)
            bolts.append(Part.makeCylinder(3.,25.,V(x,-11.,z),V(0,1,0)).fuse(Part.makeCylinder(5.1,3.,V(x,11.,z),V(0,1,0))))
    add('13 Flange bolts schematic',Part.makeCompound(bolts),(.73,.73,.82))
    seals=[]
    for i,x in enumerate((0.,aw)):
        s=S[i]
        for sign in (-1,1):
            z=sign*(s['alo']/2.+s['bp']/2.+3.)
            seals.append(cylinder(s['dpv']/2.+4.,4.,x,z-2.).cut(cylinder(s['dpv']/2.,6.,x,z-3.)))
    add('14 Shaft seals schematic',Part.makeCompound(seals),(.72,.77,.78))
    doc.recompute()
    import csv
    with open(os.path.join(output,'DIMENSIONS_mm.csv'),'w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['part','X_size_mm','Y_size_mm','Z_size_mm','volume_mm3','is_valid'])
        for name,obj in components:
            bb=obj.Shape.BoundBox;wr.writerow([name,round(bb.XLength,4),round(bb.YLength,4),round(bb.ZLength,4),round(obj.Shape.Volume,4),obj.Shape.isValid()])
    for name,obj in components:
        Part.export([obj],os.path.join(output,name+'.step'))
    Part.export([obj for _,obj in components],os.path.join(output,'AKKR_3D_Assembly_mm.step'))
    doc.saveAs(os.path.join(output,'AKKR_3D_CAD_mm.FCStd'))
    App.Console.PrintMessage('SUCCESS: STEP/FCStd and dimensions in '+output+'\n')
except Exception:
    traceback.print_exc(); App.Console.PrintError(traceback.format_exc()+'\n');raise
`;
return content.replace('__CONFIG_LITERAL__',()=>JSON.stringify(JSON.stringify(captureVariant())));
}
function exportFreeCADMacro(){
const name='AKKR_'+fileBase($('variantLabel').value)+'_FreeCAD_STEP.FCMacro';
save(name,'text/x-python',new Blob([freeCADMacroText()],{type:'text/plain;charset=utf-8'}));status('Макрос для створення твердотільних STEP у FreeCAD Desktop підготовлено.');
}
const zipEncode=new TextEncoder();
const ZIP_TABLE=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let i=0;i<8;i++)c=(c&1)?0xEDB88320^(c>>>1):c>>>1;t.push(c>>>0)}return t})();
function zipCRC(b){let c=-1;for(let i=0;i<b.length;i++)c=ZIP_TABLE[(c^b[i])&255]^(c>>>8);return(c^-1)>>>0}
function makeZip(files){
 let output=[],directory=[],at=0;
 const wr=(arr,off,value,n)=>{for(let i=0;i<n;i++)arr[off+i]=(value>>>(8*i))&255};
 for(const f of files){let name=zipEncode.encode(f.name),data=f.bytes,crc=zipCRC(data),loc=new Uint8Array(30+name.length);
  wr(loc,0,0x04034b50,4);wr(loc,4,20,2);wr(loc,6,0x800,2);wr(loc,14,crc,4);wr(loc,18,data.length,4);wr(loc,22,data.length,4);wr(loc,26,name.length,2);loc.set(name,30);
  output.push(loc,data);let cd=new Uint8Array(46+name.length);wr(cd,0,0x02014b50,4);wr(cd,4,20,2);wr(cd,6,20,2);wr(cd,8,0x800,2);wr(cd,16,crc,4);wr(cd,20,data.length,4);wr(cd,24,data.length,4);wr(cd,28,name.length,2);wr(cd,42,at,4);cd.set(name,46);directory.push(cd);at+=loc.length+data.length;
 }
 const end=new Uint8Array(22);wr(end,0,0x06054b50,4);wr(end,8,files.length,2);wr(end,10,files.length,2);wr(end,12,directory.reduce((a,v)=>a+v.length,0),4);wr(end,16,at,4);
 return new Blob([...output,...directory,end],{type:'application/zip'});
}
const partStems=['Pinion','Gear_Wheel','Input_Shaft','Output_Shaft','Bearing_Input_A','Bearing_Input_B','Bearing_Output_A','Bearing_Output_B','Key_Input','Key_Output','Lower_Housing','Curved_Cover','Flange_Bolts','Shaft_Seals'];
function meshBounds(mesh){const p=mesh.pos,mn=[Infinity,Infinity,Infinity],mx=[-Infinity,-Infinity,-Infinity];for(let i=0;i<p.length;i+=3)for(let j=0;j<3;j++){mn[j]=Math.min(mn[j],p[i+j]);mx[j]=Math.max(mx[j],p[i+j])}return{min_mm:mn,max_mm:mx,size_mm:mx.map((v,j)=>Number((v-mn[j]).toFixed(4))),triangles:p.length/9}}
async function cadBundle(){
 const cfg=captureVariant(),encoder=zipEncode,files=[];
 const push=(name,bytes)=>files.push({name,bytes});
 const manifest=[];
 for(let i=0;i<parts.length;i++){
  const filename=String(i+1).padStart(2,'0')+'_'+partStems[i]+'.stl';
  push('STL_meshes_mm/'+filename,new Uint8Array(await stlBlob([parts[i]]).arrayBuffer()));
  manifest.push({index:i+1,filename,part:parts[i].name,...meshBounds(parts[i])});
 }
 push('PARAMETERS_mm.json',encoder.encode(JSON.stringify(cfg,null,2)));
 push('MESH_BOUNDS_mm.json',encoder.encode(JSON.stringify(manifest,null,2)));
 push('GENERATE_STEP_FreeCAD.FCMacro',encoder.encode(freeCADMacroText()));
 push('ASSEMBLY_PLACEMENT_mm.csv',encoder.encode('part_id;filename;X_mm;Y_mm;Z_mm;units\n'+manifest.map((p,i)=>{const x=[0,params.a,0,params.a,0,0,params.a,params.a,0,params.a,0,0,0,0][i];const z=[0,0,0,0,-shaftInfo[0].alo/2,shaftInfo[0].alo/2,-shaftInfo[1].alo/2,shaftInfo[1].alo/2,0,0,0,0,0,0][i];return `${i+1};${p.filename};${x};0;${z};mm`}).join('\n')));
 const instructions=`АККР 3D CAD 6.0 | ${cfg.variant}\n\n`+
 `1. Розпакуй ZIP на комп'ютері.\n`+
 `2. Для SolidWorks/Autodesk Inventor у FreeCAD Desktop виконай макрос GENERATE_STEP_FreeCAD.FCMacro.\n`+
 `3. Отримаєш папку AKKR_STEP_mm з файлами STEP КОЖНОЇ деталі, STEP загальної збірки, FCStd та DIMENSIONS_mm.csv.\n`+
 `4. Inventor: Open STEP -> convert to CAD model -> Save as IPT. Create Assembly IAM and Place saved IPT.\n`+
 `5. STEP використовує mm (міліметри). Для окремого STL при імпорті ВРУЧНУ вибери mm: формат STL сам одиниць не визначає.\n`+
 `6. STL - сітка, не редаговане параметричне тіло. STEP - B-Rep з розмірами у міліметрах, але без історії побудови в Inventor.\n`+
 `7. У STEP макросі зубці - евольвентний профіль з 16 точок/фланк. Перевір корекцію, впадини, допуски, фаски й посадки перед виробництвом.\n`+
 `8. Оформлення креслень, PDF і специфікації з Android версії 6 ПОВНІСТЮ ПРИБРАНЕ за вимогою користувача.\n`;
 push('README_IMPORT_UK.txt',encoder.encode(instructions));
 return makeZip(files);
}
function exportCadBundle(){status('Створюю CAD ZIP з окремими STL, мм і генератором STEP...');cadBundle().then(blob=>{save('AKKR_'+fileBase($('variantLabel').value)+'_CAD_mm.zip','application/zip',blob);status('CAD ZIP готовий: STEP створюються на ПК через FreeCAD')}).catch(e=>status('Помилка ZIP: '+e.message,true));}
function shareCadBundle(){status('Пакую CAD деталі для надсилання...');cadBundle().then(blob=>{shareBlob('AKKR_'+fileBase($('variantLabel').value)+'_CAD_mm.zip','application/zip',blob);status('Вибери Telegram або іншу програму')}).catch(e=>status('Помилка: '+e.message,true));}
