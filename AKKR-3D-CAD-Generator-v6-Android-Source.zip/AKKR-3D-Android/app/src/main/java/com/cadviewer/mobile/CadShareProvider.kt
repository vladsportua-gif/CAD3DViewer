package com.cadviewer.mobile

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileNotFoundException

/** Private one-file-per-share cache, exposed solely using ACTION_SEND read grants. */
class CadShareProvider : ContentProvider() {
    override fun onCreate(): Boolean = true
    override fun getType(uri: Uri): String? = when (uri.lastPathSegment?.substringAfterLast('.')?.lowercase()) {
        "stl" -> "application/octet-stream"
        "obj" -> "text/plain"
        "step", "stp" -> "application/octet-stream"
        "zip" -> "application/zip"
        "fcmacro" -> "text/x-python"
        "json" -> "application/json"
        else -> "application/octet-stream"
    }
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw FileNotFoundException("Read-only")
        val name = uri.lastPathSegment ?: throw FileNotFoundException("Invalid name")
        if (name.isBlank() || name.contains('/') || name.contains('\\') || name == "." || name == "..")
            throw FileNotFoundException("Invalid name")
        val root = File(requireNotNull(context).cacheDir, "shared")
        val file = File(root, name)
        if (file.canonicalFile.parentFile != root.canonicalFile || !file.isFile) throw FileNotFoundException("Not shared")
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? {
        val name = uri.lastPathSegment ?: return null
        val f = File(requireNotNull(context).cacheDir, "shared/$name")
        val cols = projection ?: arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE)
        val cursor = android.database.MatrixCursor(cols)
        cursor.addRow(cols.map { if (it == android.provider.OpenableColumns.DISPLAY_NAME) name else if (it == android.provider.OpenableColumns.SIZE) f.length() else null })
        return cursor
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
