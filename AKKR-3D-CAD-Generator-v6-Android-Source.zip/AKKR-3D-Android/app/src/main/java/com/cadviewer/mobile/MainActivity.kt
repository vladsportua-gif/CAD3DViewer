package com.cadviewer.mobile

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

/** Offline CAD generator: 3D model previews, parametric project, STL, OBJ and FreeCAD STEP bridge. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var savePending: ByteArray? = null
    private var openJson: ValueCallback<Array<Uri>>? = null
    private val saveRequest = 1021
    private val openRequest = 1022

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9,18,30)
        window.navigationBarColor = Color.rgb(9,18,30)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(9,18,30))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.setSupportZoom(false)
            addJavascriptInterface(CadBridge(),"NativeApp")
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(webView:WebView?, callback:ValueCallback<Array<Uri>>?, params:FileChooserParams?): Boolean {
                    openJson?.onReceiveValue(null)
                    openJson=callback
                    return try {
                        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type="application/json"
                        },openRequest)
                        true
                    } catch (e:Exception) {
                        openJson=null
                        callback?.onReceiveValue(null)
                        false
                    }
                }
            }
            webViewClient = object:WebViewClient(){
                override fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest?):Boolean {
                    return request?.url?.toString()?.startsWith("file:///android_asset/") != true
                }
            }
            loadUrl("file:///android_asset/generator.html")
        }
        setContentView(web)
    }
    inner class CadBridge {
        @JavascriptInterface fun saveFile(name:String,mime:String,b64:String) {
            try {
                validate(name,b64)
                val bytes=Base64.decode(b64,Base64.DEFAULT)
                runOnUiThread {
                    savePending=bytes
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type=mime
                        putExtra(Intent.EXTRA_TITLE,name)
                    },saveRequest)
                }
            } catch(e:Exception){runOnUiThread{toast("Не вдалося зберегти: "+e.message)}}
        }
        @JavascriptInterface fun shareFile(name:String,mime:String,b64:String) {
            try {
                validate(name,b64)
                val bytes=Base64.decode(b64,Base64.DEFAULT)
                runOnUiThread {
                    try {
                        val directory=File(cacheDir,"shared").apply{mkdirs()}
                        File(directory,name).writeBytes(bytes)
                        val uri=Uri.Builder().scheme("content").authority("$packageName.share").appendPath(name).build()
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type=mime
                            putExtra(Intent.EXTRA_STREAM,uri)
                            clipData=ClipData.newUri(contentResolver,"CAD model",uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        },"Поділитися 3D CAD файлом"))
                    }catch(e:Exception){toast("Надсилання: "+e.message)}
                }
            }catch(e:Exception){runOnUiThread{toast("Надсилання: "+e.message)}}
        }
    }
    private fun validate(name:String,b64:String){
        require(name.length in 1..100 && name.all{it.isLetterOrDigit()||it=='_'||it=='.'||it=='-'}){"Некоректна назва файлу"}
        require(b64.length<65_000_000){"Занадто великий файл"}
    }
    @Deprecated("Compatibility with Android 7+")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==openRequest){
            val callback=openJson;openJson=null
            callback?.onReceiveValue(if(resultCode==RESULT_OK&&data?.data!=null)arrayOf(data.data!!)else null)
        }
        if(requestCode==saveRequest){
            val bytes=savePending;savePending=null
            if(resultCode==RESULT_OK&&data?.data!=null&&bytes!=null){
                try{
                    contentResolver.openOutputStream(data.data!!)?.use{it.write(bytes)}?:throw IllegalStateException("Cannot write document")
                    toast("CAD файл збережено")
                }catch(e:Exception){toast("Збереження: "+e.message)}
            }
        }
    }
    private fun toast(msg:String)=android.widget.Toast.makeText(this,msg,android.widget.Toast.LENGTH_LONG).show()
    override fun onDestroy(){if(::web.isInitialized)web.destroy();super.onDestroy()}
    @Deprecated("Compatibility with Android 7+")
    override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
}
