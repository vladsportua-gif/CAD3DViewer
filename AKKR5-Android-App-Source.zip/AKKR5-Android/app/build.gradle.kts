plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.cadviewer.mobile"; compileSdk = 35
    defaultConfig { applicationId = "com.akkr.assistant5.cadstudio5"; minSdk = 24; targetSdk = 35; versionCode = 5; versionName = "5.0.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
