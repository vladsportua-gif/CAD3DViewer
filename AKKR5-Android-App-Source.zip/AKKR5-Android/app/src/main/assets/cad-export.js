'use strict';
// Offline CAD bridge. FreeCAD macro produces STEP B-Rep solids on desktop; mesh files are 3D-print previews.
function freeCADMacroText(){
 const content=String.raw`# -*- coding: utf-8 -*-
# AKKR CAD Studio 5.0. RUN IN FREECAD DESKTOP: Macro -> Macros -> Execute.
# Creates separate STEP files, assembly STEP and editable FreeCAD document.
# All dimensions in mm. Geometric clearance details and gear teeth are educational approximations.
import FreeCAD as App
import Part, math, os, json, traceback
from FreeCAD import Vector as V
cfg=json.loads(__CONFIG_LITERAL__)
p=cfg['params']; ss=cfg['shafts']; sh=cfg['shell']
m=float(p['m']); z1=int(p['z1']); z2=int(p['z2']); alpha=float(p['alpha'])
center=m*(z1+z2)/2.
output=os.path.join(os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.path.expanduser('~'), 'AKKR5_STEP')
if not os.path.isdir(output): os.makedirs(output)
doc=App.newDocument('AKKR_CAD')
items=[]
def add(name,shape,basename):
    if shape.isNull(): raise RuntimeError('Empty geometry: '+name)
    obj=doc.addObject('PartDesign::Feature',basename)
    obj.Label=name
    obj.Shape=shape
    items.append((basename,obj))
    return obj

def cylinder(radius,length,x=0.,y=0.,z=0.):
    return Part.makeCylinder(float(radius),float(length),V(x,y,z),V(0,0,1))

def ring(x,z,ri,ro,width):
    out=cylinder(ro,width,x,0,z-width/2.)
    return out.cut(cylinder(ri,width+2,x,0,z-width/2.-1))

def gear_profile(z):
    rp=m*z/2.; rb=rp*math.cos(math.radians(alpha)); ra=rp+m; rf=rp-1.25*m
    def inv(r):
        t=math.sqrt(max(0,(r/rb)**2-1)); return t-math.atan(t)
    def hp(r): return math.pi/(2*z)+inv(rp)-inv(max(rb,r))
    low=max(rb,rf); n=7; points=[]
    for k in range(z):
        angle=k*2*math.pi/z
        def put(r,a): points.append((r*math.cos(angle+a),r*math.sin(angle+a)))
        put(rf,-hp(low))
        if low>rf+1.e-7: put(low,-hp(low))
        for j in range(1,n+1):
            r=low+(ra-low)*j/n; put(r,-hp(r))
        for j in range(1,4): put(ra,-hp(ra)+2*hp(ra)*j/3)
        for j in range(n-1,-1,-1):
            r=low+(ra-low)*j/n; put(r,hp(r))
        put(rf,hp(low))
    return points

def prism_xy(points, z0, length):
    verts=[V(float(a),float(b),z0) for a,b in points]
    wire=Part.makePolygon(verts+[verts[0]])
    return Part.Face(wire).extrude(V(0,0,length))

def gear(n,b,x,bore):
    shape=prism_xy(gear_profile(n),-b/2.,b)
    shape=shape.cut(cylinder(bore/2.,b+4,0,0,-b/2.-2))
    shape.translate(V(x,0,0))
    return shape

def shaft(s,x):
    length=s['alv']; pos=s['alo']/2.
    rods=[cylinder(s['dm']/2.,length,x,0,-length/2.)]
    for sign in (-1,1):
        z=sign*pos-(s['bp']+4)/2.
        rods.append(cylinder(s['dpv']/2.,s['bp']+4,x,0,z))
    rods.append(cylinder(s['dpr']/2.,s['alk']+2*s['alb'],x,0,-s['alk']/2.-s['alb']))
    rods.append(cylinder(s['dk']/2.,s['alk'],x,0,-s['alk']/2.))
    for sign in (-1,1):
        z=sign*(s['alk']/2.+s['alb']/2.)-s['alb']/2.
        rods.append(cylinder(s['db']/2.,s['alb'],x,0,z))
    shape=rods[0]
    for r in rods[1:]:shape=shape.fuse(r)
    # Shallow keyway cut. Position/depth schematic; verify shaft fit and standard.
    channel=Part.makeBox(s['keyH']/2.+2,s['keyW'],s['keyL'],V(x+s['dk']/2.-s['keyH']/2.,-s['keyW']/2.,-s['keyL']/2.))
    return shape.cut(channel)

def key(s,x):
    return Part.makeBox(s['keyH'],s['keyW'],s['keyL'],V(x+s['dk']/2.-s['keyH']/2.,-s['keyW']/2.,-s['keyL']/2.))

def envelope():
    small=m*(z1+2)/2.; big=m*(z2+2)/2.
    return (-small-sh['gapPinion']-sh['wall']-8,
            center+big+sh['gapPinion']+sh['wall']+8,
            -big-sh['gapWheel']-sh['wall'],
            max(p['b1'],p['b2'])/2.+sh['bearingBoss']/2.+14)
x0,x1,bottom,h=envelope()
t=sh['wall']
def roof(x):
    r1=m*(z1+2)/2.+sh['gapPinion']+t
    r2=m*(z2+2)/2.+sh['gapPinion']+t
    def arc(cx,r):
        d=x-cx
        return math.sqrt(max(0,r*r-d*d)) if abs(d)<r else 0.
    return max(t+8,arc(0,r1),arc(center,r2))
def cover_shape():
    n=140
    outer=[(x0,0),(x1,0)]
    outer += [(x1+(x0-x1)*i/n, roof(x1+(x0-x1)*i/n)) for i in range(n+1)]
    body=prism_xy(outer,-h,2*h)
    inside=[(x0+t,-t),(x1-t,-t)]
    inside += [(x1-t+(x0+2*t-x1)*i/n,max(t,roof(x1-t+(x0+2*t-x1)*i/n)-t)) for i in range(n+1)]
    void=prism_xy(inside,-h+t,2*(h-t))
    body=body.cut(void)
    for side in (-1,1):
        z=side*h-sh['flangeWidth']/2.
        flange=Part.makeBox(x1-x0+20,sh['flangeThick']/2.,sh['flangeWidth'],V(x0-10,0,z))
        body=body.fuse(flange)
    for i,x in enumerate((0,center)):
        # Open half bearing seats along the shaft axis Z.
        seat=cylinder(ss[i]['dpz']/2.+.6,2*h+3,x,0,-h-1.5)
        body=body.cut(seat)
    return body

def housing_shape():
    out=Part.makeBox(x1-x0,-bottom,2*h,V(x0,bottom,-h))
    inside=Part.makeBox(x1-x0-2*t,-bottom,2*h-2*t,V(x0+t,bottom+t,-h+t))
    body=out.cut(inside)
    for side in (-1,1):
        z=side*h-sh['flangeWidth']/2.
        body=body.fuse(Part.makeBox(x1-x0+20,sh['flangeThick']/2.,sh['flangeWidth'],V(x0-10,-sh['flangeThick']/2.,z)))
    for i,x in enumerate((0,center)):
        seat=cylinder(ss[i]['dpz']/2.+.6,2*h+3,x,0,-h-1.5)
        body=body.cut(seat)
    return body

try:
    add('01 - Pinion',gear(z1,p['b1'],0,ss[0]['dk']),'01_Pinion')
    add('02 - Gear wheel',gear(z2,p['b2'],center,ss[1]['dk']),'02_Gear')
    add('03 - Input shaft',shaft(ss[0],0),'03_Input_Shaft')
    add('04 - Output shaft',shaft(ss[1],center),'04_Output_Shaft')
    for i,x in enumerate((0,center)):
        s=ss[i]
        for j,sign in enumerate((-1,1)):
            add('Bearing %s%s'%(i+1,j+1),ring(x,sign*s['alo']/2.,s['dpv']/2.,s['dpz']/2.,s['bp']),'%02d_Bearing_%d'%(5+i*2+j,i+1))
    add('09 - Input key',key(ss[0],0),'09_Input_Key')
    add('10 - Output key',key(ss[1],center),'10_Output_Key')
    add('11 - Lower housing',housing_shape(),'11_Housing')
    add('12 - Arched upper cover',cover_shape(),'12_Arched_Cover')
    # Fixings/seals simplified: actual DIN/DSTU series must be selected before production.
    bolts=[]
    for x in (x0+16,(x0+center)/2.,center+40,x1-16):
        for side in (-1,1):
            z=side*(h+4)
            bolts.append(Part.makeCylinder(3,25,V(x,-11,z),V(0,1,0)).fuse(Part.makeCylinder(5.3,3,V(x,11,z),V(0,1,0))))
    add('13 - Flange bolts (schematic)',Part.makeCompound(bolts),'13_Flange_Bolts')
    seals=[]
    for i,x in enumerate((0,center)):
        s=ss[i]
        for sign in (-1,1):
            z=sign*(s['alo']/2.+s['bp']/2.+3)
            seals.append(ring(x,z,s['dpv']/2.,s['dpv']/2.+4.5,4))
    add('14 - Shaft seals (schematic)',Part.makeCompound(seals),'14_Shaft_Seals')
    doc.recompute()
    for filename,obj in items:
        Part.export([obj],os.path.join(output,filename+'.step'))
    Part.export([obj for _,obj in items],os.path.join(output,'AKKR5_Full_Assembly.step'))
    doc.saveAs(os.path.join(output,'AKKR5_Reductor.FCStd'))
    print('AKKR CAD Studio: STEP + FCStd exported to '+output)
    App.Console.PrintMessage('CAD export finished: '+output+'\n')
except Exception:
    traceback.print_exc()
    App.Console.PrintError(traceback.format_exc()+'\n')
    raise
`;
 return content.replace('__CONFIG_LITERAL__',()=>JSON.stringify(JSON.stringify(captureVariant())));
}
function exportFreeCADMacro(){
 const name='AKKR_'+fileBase($('variantLabel').value)+'_STEP_generator.FCMacro';
 save(name,'text/x-python',new Blob([freeCADMacroText()],{type:'text/plain;charset=utf-8'}));
 status('Збережи .FCMacro на ПК. Запусти у FreeCAD — він створить окремі STEP, збірку STEP і .FCStd.');
}
// Uncompressed ZIP (STORE) with CRC-32. No external scripts or internet permission required.
const zipEncode=new TextEncoder();
const ZIP_TABLE=(()=>{let t=[];for(let n=0;n<256;n++){let c=n;for(let i=0;i<8;i++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);t.push(c>>>0)}return t})();
function zipCRC(b){let c=-1;for(let i=0;i<b.length;i++)c=ZIP_TABLE[(c^b[i])&255]^(c>>>8);return(c^-1)>>>0}
function makeZip(files){
 let output=[],directory=[],at=0;
 const wr=(arr,off,value,n)=>{for(let i=0;i<n;i++)arr[off+i]=(value>>>(8*i))&255};
 for(const f of files){let name=zipEncode.encode(f.name),data=f.bytes,crc=zipCRC(data),loc=new Uint8Array(30+name.length);
   wr(loc,0,0x04034b50,4);wr(loc,4,20,2);wr(loc,6,0x800,2);wr(loc,14,crc,4);wr(loc,18,data.length,4);wr(loc,22,data.length,4);wr(loc,26,name.length,2);loc.set(name,30);
   output.push(loc,data);let cd=new Uint8Array(46+name.length);wr(cd,0,0x02014b50,4);wr(cd,4,20,2);wr(cd,6,20,2);wr(cd,8,0x800,2);wr(cd,16,crc,4);wr(cd,20,data.length,4);wr(cd,24,data.length,4);wr(cd,28,name.length,2);wr(cd,42,at,4);cd.set(name,46);directory.push(cd);at+=loc.length+data.length;
 }
 const end=new Uint8Array(22);wr(end,0,0x06054b50,4);wr(end,8,files.length,2);wr(end,10,files.length,2);wr(end,12,directory.reduce((a,v)=>a+v.length,0),4);wr(end,16,at,4);
 return new Blob([...output,...directory,end],{type:'application/zip'});
}
const partStems=['Pinion','Gear_Wheel','Input_Shaft','Output_Shaft','Bearing_Input_A','Bearing_Input_B','Bearing_Output_A','Bearing_Output_B','Key_Input','Key_Output','Lower_Housing','Arched_Cover','Flange_Bolts','Shaft_Seals'];
function cadBundle(){
 let cfg=captureVariant(),encoder=zipEncode,files=[],partManifest=[];
 const push=(name,bytes)=>files.push({name,bytes});
 for(let i=0;i<parts.length;i++){
  const part=parts[i],meshName=String(i+1).padStart(2,'0')+'_'+partStems[i]+'.stl';
  push('STL_parts/'+meshName,new Uint8Array([]));
  // stlBlob is a browser Blob. DataView conversion happens asynchronously below.
  partManifest.push({filename:meshName,index:i,part,blob:stlBlob([part])});
 }
 push('AKKR_variant_parameters.json',encoder.encode(JSON.stringify(cfg,null,2)));
 if(typeof getProjectAsJSON==='function')push('AKKR_drawing_editor.json',encoder.encode(getProjectAsJSON()));
 push('AKKR_FreeCAD_to_STEP.FCMacro',encoder.encode(freeCADMacroText()));
 push('PARTS_PLACEMENT.csv',encoder.encode('position;component;origin_x_mm;origin_y_mm;origin_z_mm;coordinate_system\n'+parts.map((part,i)=>{const x=[0,params.a,0,params.a,0,0,params.a,params.a,0,params.a,0,0,0,0][i];const z=[0,0,0,0,-shaftInfo[0].alo/2,shaftInfo[0].alo/2,-shaftInfo[1].alo/2,shaftInfo[1].alo/2,0,0,0,0,0,0][i];return `${i+1};${part.name};${x};0;${z};assembly_global`}).join('\n')));
 push('README_IMPORT_UK.txt',encoder.encode('АККР CAD Studio 5 — CAD експорт.\r\n'+
 'Окремі STL — трикутні сітки в міліметрах (у самому STL немає одиниць вимірювання).\r\n'+
 'Усі STL мають ГЛОБАЛЬНІ координати збірки; імпортуй із міліметрами та початковою позицією 0,0,0.\r\n'+
 'Для Autodesk Inventor зі справжніми STEP твердими тілами розпакуй ZIP, відкрий FreeCAD Desktop, меню Macro > Macros > вибрати AKKR_FreeCAD_to_STEP.FCMacro > Execute.\r\n'+
 'Після запуску поруч із макросом виникне папка AKKR5_STEP (всі деталі .step + повна збірка .step + FCStd).\r\n'+
 'Inventor: File > Open > Import CAD Formats > STEP (Convert Model). Для власної збірки імпортуй окремі STEP, збережи як IPT, потім створи IAM.\r\n'+
 'Шестерні, посадкові місця, болти, корпус і кришка наближені, не готові до виробництва без перевірки. Перевір сітку перед 3D друком.\r\n'));
 return Promise.all(partManifest.map(async p=>new Uint8Array(await p.blob.arrayBuffer()))).then(buffers=>{
  buffers.forEach((bytes,i)=>files[i].bytes=bytes);
  return makeZip(files);
 });
}
function exportCadBundle(){status('Підготовка ZIP із STL/STEP-макросом…');cadBundle().then(blob=>{
 save('AKKR_'+fileBase($('variantLabel').value)+'_CAD_Package.zip','application/zip',blob);
 status('ZIP сформовано. STEP будуть створені макросом FreeCAD Desktop.');
 }).catch(e=>status('Не вдалося створити ZIP: '+e.message,true));}
function shareCadBundle(){status('Формування пакета CAD для надсилання…');cadBundle().then(blob=>{
 shareBlob('AKKR_'+fileBase($('variantLabel').value)+'_CAD_Package.zip','application/zip',blob);
 status('У меню Android обери Telegram, Drive або іншу програму.');
 }).catch(e=>status('Помилка: '+e.message,true));}
