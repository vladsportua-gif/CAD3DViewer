'use strict';
/* Editable A3 drawing sheets and A4 specification. Based on DSTU GOST 2.104:2006,
 * GOST 2.301-68 and GOST 2.106-96. Educational template: user must verify dimensions. */
const projectKey='akkr5-cadstudio-v5-project';
const defaults={author:'Сотниченко В.',checker:'',controller:'',approved:'',group:'ГМІ-23-1',organization:'ІФНТУНГ',material:'Не визначено',mass:'—',scale:'1:1',litera:'Н',date:'',codePrefix:'АККР.05',titles:{},codes:{},scales:{},annotations:{},specRows:null};
let project;try{const load=JSON.parse(localStorage.getItem(projectKey)||'{}');project={...defaults,...load,titles:load.titles||{},codes:load.codes||{},scales:load.scales||{},annotations:load.annotations||{}};}catch(e){project={...defaults,titles:{},codes:{},scales:{},annotations:{}}}
const escDraft=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&gt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
// Correct SVG escape for content, independent of the older file helpers.
function safe(v){return String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
function persist(){try{localStorage.setItem(projectKey,JSON.stringify(project))}catch(e){status('Сховище переповнене: збережи проєкт JSON',true)}}
function sheetId(){return $('drawingPart')?.value||'assembly'}
function standardName(id){const list={assembly:'Редуктор одноступеневий. Складальний кресленик',spec:'Специфікація редуктора','0':'Шестерня','1':'Колесо зубчасте','2':'Вал-шестерня','3':'Вал колеса','4':'Підшипник вала 1','5':'Підшипник вала 1','6':'Підшипник вала 2','7':'Підшипник вала 2','8':'Шпонка 1','9':'Шпонка 2','10':'Корпус редуктора','11':'Кришка редуктора','12':'Болт кріпильний','13':'Ущільнення'};return list[id]||'Деталь редуктора'}
function currentName(){return project.titles[sheetId()]||standardName(sheetId())}
function currentCode(){const id=sheetId();if(project.codes[id])return project.codes[id];if(id==='assembly')return project.codePrefix+'.00.000 СК';if(id==='spec')return project.codePrefix+'.00.000 СП';return project.codePrefix+'.'+String(Number(id)+1).padStart(2,'0')+'.000';}
const cadStyle=`<style>text{font-family:Arial,'DejaVu Sans',sans-serif;fill:#171717;font-size:12px}.dim{stroke:#111;stroke-width:.8;fill:none}.dim text{fill:#111}.solid{stroke:#111;stroke-width:1.25;fill:#fff}.center{stroke:#666;stroke-width:.65;stroke-dasharray:12 2 2 2;fill:none}.outline{stroke:#111;stroke-width:1.35;fill:none}.line{stroke:#111;stroke-width:.6;fill:none}.hdr{font-weight:bold;font-size:14px}.small{font-size:9px}.micro{font-size:8px}.tb{stroke:#111;stroke-width:.9;fill:#fff}.fine{stroke:#333;stroke-width:.45;fill:none}.solid-hatched{stroke:#111;stroke-width:1.1;fill:url(#hatch45)}.annot{stroke:#111;stroke-width:1.25;fill:none}.edit-item{stroke:#111;fill:none;stroke-width:1.2}.edit-item.selected{stroke:#1767c5}</style><defs><pattern id="hatch45" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" stroke="#777" stroke-width="1"/></pattern><marker id="arrowG" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6z" fill="#111"/></marker></defs>`;
function displayFit(value,max){let t=safe(value);return t.length>max?t.slice(0,max-1)+'…':t}
function form1(){// 370x110 svg units = 185x55 physical millimeters.
  const x=450,y=474,code=displayFit(currentCode(),46),title=displayFit(currentName(),44),material=displayFit(project.material,42),group=displayFit(project.group,20);
  return `<g id="titleBlock"><rect class="tb" x="${x}" y="${y}" width="370" height="110"/><path class="line" d="M570 474V584 M570 497H820 M570 538H820 M450 496H570 M450 518H570 M450 540H570 M450 562H570 M623 538V584 M700 538V584 M741 538V584 M778 538V584 M623 560H820 M700 548H820 M741 548H820 M778 548H820 M570 573H623"/>
  <g font-size="9"><text x="455" y="483" class="micro">Змін.  Арк.  №док.  Підп.  Дата</text>
  <text x="456" y="508" class="micro">Розроб.</text><text x="497" y="511" class="micro">${displayFit(project.author,16)}</text>
  <text x="456" y="530" class="micro">Перев.</text><text x="497" y="533" class="micro">${displayFit(project.checker,16)}</text>
  <text x="456" y="552" class="micro">Н.контр.</text><text x="497" y="555" class="micro">${displayFit(project.controller,16)}</text>
  <text x="456" y="574" class="micro">Затв.</text><text x="497" y="577" class="micro">${displayFit(project.approved,16)}</text>
  <text x="577" y="491" font-size="12" font-weight="700">${code}</text>
  <text x="578" y="512" font-size="12" font-weight="700">${title.length>39?title.slice(0,39)+'…':title}</text>
  <text x="578" y="530" class="small">${material}</text>
  <text x="573" y="551" class="micro">${displayFit(project.organization,10)}</text><text x="573" y="569" class="micro">${group}</text>
  <text x="633" y="551" class="micro">Літ.</text><text x="636" y="578">${safe(project.litera)}</text>
  <text x="710" y="545" class="micro">Маса</text><text x="705" y="575" class="small">${displayFit(project.mass,6)}</text>
  <text x="745" y="545" class="micro">Масш.</text><text x="743" y="576">${displayFit(project.scales[sheetId()]||project.scale,7)}</text>
  <text x="784" y="545" class="micro">Арк.</text><text x="784" y="560">1</text>
  <text x="785" y="570" class="micro">Аркушів</text><text x="792" y="581">1</text></g></g>`;
}
// Replace the old not-to-scale stamp with a 185x55mm title block and proper margins.
const baseFrame=svgFrame;
svgFrame=function(content,title){return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 840 594" width="420mm" height="297mm">${cadStyle}<rect width="840" height="594" fill="#fff"/><rect x="40" y="10" width="790" height="574" fill="none" stroke="#111" stroke-width="1.3"/><text x="49" y="21" class="micro">${safe(currentCode())}</text><g id="geometry">${content}</g>${form1()}</svg>`};
function defaultSpecRows(){return [
 {section:'Документація',pos:'',code:'',name:'',qty:'',note:''},
 {section:'',pos:'',code:project.codePrefix+'.00.000 СК',name:'Складальний кресленик',qty:'1',note:'А3'},
 {section:'Деталі',pos:'',code:'',name:'',qty:'',note:''},
 ...[['1','Корпус','1'],['2','Кришка','1'],['3','Вал шестерні','1'],['4','Вал колеса','1'],['5','Шестерня','1'],['6','Колесо зубчасте','1']].map(([pos,name,qty])=>({section:'',pos,code:project.codePrefix+'.'+String(Number(pos)+9).padStart(2,'0')+'.000',name,qty,note:''})),
 {section:'Стандартні вироби',pos:'',code:'',name:'',qty:'',note:''},
 ...[['7','Підшипник 25×42×9','2'],['8','Підшипник 40×62×12','2'],['9','Шпонка 10×8×41','1'],['10','Шпонка 14×9×36','1'],['11','Кріплення (умовне)','8'],['12','Ущільнення (умовне)','4']].map(([pos,name,qty])=>({section:'',pos,code:'',name,qty,note:'Уточнити'}))
 ]}
if(!project.specRows)project.specRows=defaultSpecRows();
function specPortrait(){let c=`<rect x="40" y="10" width="370" height="574" fill="none" stroke="#111" stroke-width="1.3"/><text x="45" y="25" class="micro">${safe(currentCode())}</text>`;
 const col=[40,65,90,115,210,352,377,410]; const start=42,rowHeight=16;
 for(const px of col.slice(1,-1))c+=`<path class="fine" d="M${px} ${start}V504"/>`;
 c+=`<path class="fine" d="M40 42H410 M40 70H410"/><g font-size="8" font-family="Arial" fill="#111"><text x="42" y="58" font-size="7">Форм.</text><text x="67" y="58" font-size="7">Зона</text><text x="94" y="58" font-size="7">Поз.</text><text x="119" y="58" font-size="7">Позначення</text><text x="213" y="58" font-size="8">Найменування</text><text x="355" y="58" font-size="7">Кіл.</text><text x="379" y="58" font-size="7">Прим.</text></g>`;
 const rows=project.specRows.slice(0,25);rows.forEach((r,i)=>{const yy=70+i*rowHeight;if(yy>495)return;c+=`<path class="fine" d="M40 ${yy+rowHeight}H410"/>`;if(r.section)c+=`<text x="213" y="${yy+12}" font-size="9" font-weight="bold" text-decoration="underline">${displayFit(r.section,27)}</text>`;else c+=`<g font-family="Arial" font-size="9" fill="#111"><text x="93" y="${yy+11}">${safe(r.pos)}</text><text x="118" y="${yy+11}" font-size="7">${displayFit(r.code,23)}</text><text x="213" y="${yy+11}">${displayFit(r.name,26)}</text><text x="358" y="${yy+11}">${safe(r.qty)}</text><text x="379" y="${yy+11}" font-size="6.5">${displayFit(r.note,7)}</text></g>`});
 c+=`<path class="fine" d="M40 504H410"/><rect x="40" y="504" width="370" height="80" fill="white" stroke="#111" stroke-width="1"/><path class="fine" d="M150 504V584 M150 525H410 M150 548H410 M270 548V584 M335 548V584 M40 524H150 M40 545H150 M40 565H150"/>`;
 c+=`<text x="46" y="514" font-size="8">Розроб.</text><text x="86" y="519" font-size="7">${displayFit(project.author,11)}</text><text x="46" y="536" font-size="8">Перев.</text><text x="86" y="541" font-size="7">${displayFit(project.checker,11)}</text><text x="46" y="557" font-size="8">Н.контр.</text><text x="86" y="561" font-size="7">${displayFit(project.controller,11)}</text><text x="46" y="576" font-size="8">Затв.</text><text x="86" y="581" font-size="7">${displayFit(project.approved,11)}</text>`;
 c+=`<text x="157" y="520" font-size="12" font-weight="bold">${displayFit(currentCode(),34)}</text><text x="157" y="541" font-size="13" font-weight="bold">${displayFit(currentName(),28)}</text><text x="156" y="558" font-size="8">${safe(project.organization)}</text><text x="155" y="578" font-size="10">${safe(project.group)}</text><text x="275" y="563" font-size="8">Літ.</text><text x="280" y="578">${safe(project.litera)}</text><text x="340" y="560" font-size="8">Арк. 1</text><text x="340" y="577" font-size="8">Аркушів 1</text>`;
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 594" width="210mm" height="297mm">${cadStyle}<rect width="420" height="594" fill="white"/>${c}</svg>`.replace(/font-size="([0-9.]+)"/g, 'style="font-size:$1px"');
}
specSVG=function(){return specPortrait()};
// Gear side-section and a separate gear-data table similar to textbook Appendix A.
gearSVG=function(g,i){const z=g.z,m=params.m,ra=m*(z+2)/2,dr=m*(z-2.5),d=m*z,rr=142/ra,cx=212,cy=248,contour=gearContour(z,m,params.alpha);const pts=contour.map(p=>`${(cx+p[0]*Math.cos(p[1])*rr).toFixed(2)},${(cy+p[0]*Math.sin(p[1])*rr).toFixed(2)}`).join(' ');
let c=`<polygon points="${pts}" fill="white" stroke="#111" stroke-width="1.3"/><circle cx="${cx}" cy="${cy}" r="${g.bore*rr/2}" fill="white" stroke="#111" stroke-width="2"/><circle class="center" cx="${cx}" cy="${cy}" r="${d*rr/2}"/><path class="center" d="M50 248H365 M212 87V410"/><text x="69" y="435" class="small">Вигляд збоку</text>${svgDim(70,414,355,414,'Øda '+format(ra*2))}`;
// Section: annular rim as two hatched slabs, hub with unhatched through hole.
const sx=515,sy=296,bl=Math.min(112,g.b*2.2),h=110,yt=sy-h/2,yb=sy+h/2;
c+=`<rect x="${sx}" y="${yt}" width="${bl}" height="${h}" class="solid-hatched"/><rect x="${sx}" y="${sy-17}" width="${bl}" height="34" fill="white" stroke="#111"/><path class="center" d="M485 ${sy}H${sx+bl+26}"/>${svgDim(sx,385,sx+bl,385,'b = '+format(g.b))}<text x="${sx}" y="415" class="small">Поздовжній розріз А–А</text>`;
const t=[['Модуль, мм','m',format(m)],['Число зубців','z',z],['Ділильний Ø','d',format(d)],['Ø вершин','da',format(2*ra)],['Ø западин','df',format(dr)],['Ширина вінця','b',format(g.b)],['Кут профілю','α',format(params.alpha)+'°']];
c+=`<rect x="480" y="62" width="302" height="142" fill="white" stroke="#111"/><text x="489" y="76" class="small" font-weight="bold">Параметри зубчастого вінця</text>`;for(let i=0;i<t.length;i++){const yy=83+i*17;c+=`<path class="fine" d="M480 ${yy}H782"/><text x="487" y="${yy+12}" class="micro">${t[i][0]}</text><text x="699" y="${yy+12}" class="micro">${t[i][1]}</text><text x="745" y="${yy+12}" class="micro">${t[i][2]}</text>`}c+=`<path class="fine" d="M687 83V204 M733 83V204"/><text x="84" y="465" class="small">Параметри: m=${format(m)} мм; z=${z}; α=${format(params.alpha)}°.</text>`;
return svgFrame(c,g.name)};
// Section A-A and B-B, keyed seats and technical notes on shafts.
const oldShaft=shaftSVG;shaftSVG=function(s,i){let raw=oldShaft(s,i),cut=`<g id="shaftSections"><text x="632" y="74" class="small">А–А</text><circle class="solid-hatched" cx="695" cy="132" r="31"/><rect x="685" y="98" width="20" height="13" fill="#fff" stroke="#111"/><path class="center" d="M653 132H737 M695 92V173"/><text x="627" y="209" class="small">Б–Б</text><circle class="solid-hatched" cx="695" cy="260" r="38"/><rect x="682" y="221" width="26" height="16" fill="#fff" stroke="#111"/><path class="center" d="M645 260H745 M695 212V311"/><text x="621" y="328" class="micro">Шпонкові пази (схематично)</text></g><text x="80" y="460" class="micro">1. Радіуси галтелей, фаски, шорсткість уточнити за робочим кресленням.</text>`;
return raw.replace('</g><g id="titleBlock">',''+cut+'</g><g id="titleBlock">')};
// Persistent editable annotations per selected sheet: text, dimension, line, circle, rectangle.
let tool='select',draftStart=null,selected=-1,history=[],future=[],dragFrom=null;
function annotationsFor(id=sheetId()){return project.annotations[id]||(project.annotations[id]=[])}
function snapshot(){history.push(JSON.stringify(project.annotations));if(history.length>45)history.shift();future=[]}
function undoDrawing(){if(!history.length)return;future.push(JSON.stringify(project.annotations));project.annotations=JSON.parse(history.pop());selected=-1;persist();drawDrawing()}
function redoDrawing(){if(!future.length)return;history.push(JSON.stringify(project.annotations));project.annotations=JSON.parse(future.pop());selected=-1;persist();drawDrawing()}
function itemSVG(a,i){const attr=`data-edit-index="${i}" class="edit-item ${i===selected&&editMode()?'selected':''}"`;
 if(a.kind==='text')return `<text ${attr} x="${a.x}" y="${a.y}" style="font-family:Arial,sans-serif;font-size:${a.size||13}px;stroke:none;fill:#111">${safe(a.text)}</text>`;
 if(a.kind==='circle')return `<circle ${attr} cx="${a.x}" cy="${a.y}" r="${Math.max(1,a.r||30)}"/>`;
 if(a.kind==='rect')return `<rect ${attr} x="${Math.min(a.x,a.x2)}" y="${Math.min(a.y,a.y2)}" width="${Math.abs(a.x2-a.x)}" height="${Math.abs(a.y2-a.y)}"/>`;
 if(a.kind==='line')return `<line ${attr} x1="${a.x}" y1="${a.y}" x2="${a.x2}" y2="${a.y2}"/>`;
 if(a.kind==='dim'){const mx=(a.x+a.x2)/2,my=(a.y+a.y2)/2;return `<g ${attr}><path d="M${a.x} ${a.y}L${a.x2} ${a.y2}" fill="none" stroke="#111" stroke-width=".85" marker-start="url(#arrowG)" marker-end="url(#arrowG)"/><text x="${mx}" y="${my-6}" text-anchor="middle" font-size="12" fill="#111">${safe(a.text||'Розмір')}</text></g>`}return '';
}
function currentAnnotationGroup(){return `<g id="editorAnnotations">${annotationsFor().map(itemSVG).join('')}</g>`}
const prevDrawingSVG=drawingSVG;
drawingSVG=function(){let v=prevDrawingSVG();return v.replace('</svg>',currentAnnotationGroup()+'</svg>')};
function editMode(){return $('tab-draw')&&!$('tab-draw').classList.contains('hidden')}
const prevDrawDrawing=drawDrawing;drawDrawing=function(){prevDrawDrawing();const svg=$('drawing').querySelector('svg');if(!svg)return;svg.classList.add('editing');svg.addEventListener('pointerdown',pointerDown);svg.addEventListener('pointermove',pointerMove);svg.addEventListener('pointerup',pointerUp);svg.addEventListener('pointercancel',()=>draftStart=null);refreshTitleFields();}
function svgCoord(svg,e){const pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;const mat=svg.getScreenCTM();if(!mat)return{x:0,y:0};const local=pt.matrixTransform(mat.inverse());return{x:Math.round(local.x),y:Math.round(local.y)}}
function pointerDown(e){if(e.button!==0 && e.pointerType==='mouse')return;const svg=e.currentTarget,where=svgCoord(svg,e),el=e.target.closest('[data-edit-index]');if(tool==='select'&&el){snapshot();selected=Number(el.getAttribute('data-edit-index'));dragFrom=where;svg.setPointerCapture(e.pointerId);showSelection();return}
 if(tool==='erase'&&el){snapshot();annotationsFor().splice(Number(el.dataset.editIndex),1);selected=-1;persist();drawDrawing();return}
 if(tool==='text'){let t=prompt('Введи текст для креслення','Примітка');if(t===null)return;snapshot();annotationsFor().push({kind:'text',x:where.x,y:where.y,text:t,size:12});persist();drawDrawing();return}
 if(tool==='line'||tool==='dim'||tool==='rect'||tool==='circle'){draftStart=where;svg.setPointerCapture(e.pointerId);e.preventDefault();}
}
function pointerMove(e){if(tool==='select'&&dragFrom&&selected>=0){const v=svgCoord(e.currentTarget,e),dx=v.x-dragFrom.x,dy=v.y-dragFrom.y;const el=annotationsFor()[selected];if(!el)return;el.x+=dx;el.y+=dy;if(Number.isFinite(el.x2)){el.x2+=dx;el.y2+=dy}dragFrom=v;const node=e.currentTarget.querySelector('[data-edit-index="'+selected+'"]');if(node){node.setAttribute('transform',`translate(${(Number(node.dataset.dragX)||0)+dx} ${(Number(node.dataset.dragY)||0)+dy})`);node.dataset.dragX=(Number(node.dataset.dragX)||0)+dx;node.dataset.dragY=(Number(node.dataset.dragY)||0)+dy;}return} }
function pointerUp(e){if(dragFrom){dragFrom=null;persist();drawDrawing();return}if(!draftStart)return;const to=svgCoord(e.currentTarget,e),from=draftStart;draftStart=null;if(Math.hypot(to.x-from.x,to.y-from.y)<5)return;let a={kind:tool,x:from.x,y:from.y,x2:to.x,y2:to.y};if(tool==='circle')a={kind:'circle',x:from.x,y:from.y,r:Math.round(Math.hypot(to.x-from.x,to.y-from.y))};if(tool==='dim'){const t=prompt('Напис розміру (мм, Ø, R, кут):','25');if(t===null)return;a.text=t}snapshot();annotationsFor().push(a);persist();drawDrawing()}
function selectTool(id){tool=id;selected=-1;for(const b of document.querySelectorAll('[data-cadtool]'))b.classList.toggle('chosen',b.dataset.cadtool===id);$('cadToolHint').textContent={'select':'Натисни на доданий елемент, щоб виділити; утримуй і переміщуй.','text':'Натисни місце для нового напису.','line':'Протягни від початку до кінця лінії.','rect':'Протягни діагональ прямокутника.','circle':'Протягни від центра до точки кола.','dim':'Протягни розмірну лінію, потім введи текст.','erase':'Натисни на доданий елемент для видалення.'}[id];drawDrawing()}
function showSelection(){const svg=$('drawing').querySelector('svg');if(svg){svg.querySelectorAll('[data-edit-index]').forEach(e=>e.classList.toggle('selected',Number(e.dataset.editIndex)===selected))}const panel=$('selectedProperties');if(selected<0||!annotationsFor()[selected]){panel.hidden=true;return}const a=annotationsFor()[selected];panel.hidden=false;$('selectedLabel').textContent=`Елемент №${selected+1} · ${a.kind}`;$('selectedText').value=a.text||'';$('selectedTextBox').style.display=(a.kind==='text'||a.kind==='dim')?'flex':'none'}
function updateSelectedText(){const a=annotationsFor()[selected];if(!a)return;snapshot();a.text=$('selectedText').value;persist();drawDrawing();showSelection()}
function removeSelected(){if(selected<0)return;snapshot();annotationsFor().splice(selected,1);selected=-1;persist();drawDrawing();showSelection()}
function clearAnnotations(){if(!confirm('Очистити всі власні позначки на поточному аркуші?'))return;snapshot();project.annotations[sheetId()]=[];persist();drawDrawing()}
function refreshTitleFields(){for(const [id,key] of [['cadAuthor','author'],['cadChecker','checker'],['cadNorm','controller'],['cadApproved','approved'],['cadGroup','group'],['cadOrganization','organization'],['cadMaterial','material'],['cadScale','scale'],['cadMass','mass'],['cadPrefix','codePrefix'],['cadLitera','litera']]){let input=$(id);if(input&&document.activeElement!==input)input.value=project[key]||'';}const c=$('cadCode'),n=$('cadName');if(c&&document.activeElement!==c)c.value=currentCode();if(n&&document.activeElement!==n)n.value=currentName();const spec=$('cadSpecRows');if(spec)spec.style.display=sheetId()==='spec'?'block':'none';}
function changeField(id,key){project[key]=$(id).value;persist();drawDrawing()}
function changeSheetField(id,key){project[key][sheetId()]=$(id).value;persist();drawDrawing()}
function getProjectAsJSON(){return JSON.stringify({app:'AKKR CAD Studio',version:5,variantConfig:captureVariant(),project},null,2)}
function saveProject(){save('AKKR5_editor_project_v5.json','application/json',new Blob([getProjectAsJSON()],{type:'application/json;charset=utf-8'}))}
function loadProject(file){if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const obj=JSON.parse(reader.result);if(obj.app!=='AKKR CAD Studio'||![4,5].includes(obj.version))throw Error('Це не проєкт CAD Studio');if(obj.version===5&&obj.variantConfig)applyVariant(obj.variantConfig);else if(obj.params){for(let[id,key]of[['module','m'],['z1','z1'],['z2','z2'],['b1','b1'],['b2','b2'],['alpha','alpha']])$(id).value=obj.params[key];regenerate()}project={...defaults,...obj.project,titles:obj.project.titles||{},codes:obj.project.codes||{},scales:obj.project.scales||{},annotations:obj.project.annotations||{}};persist();history=[];future=[];drawDrawing();drawSpecRows();status('Проєкт і параметри відкрито')}catch(err){status('Помилка проєкту: '+err.message,true)}};reader.readAsText(file);}
function drawSpecRows(){let el=$('cadSpecEditor');if(!el)return;el.innerHTML=project.specRows.map((row,i)=>`<div class="cad-specrow"><input aria-label="Поз. ${i+1}" placeholder="№" value="${safe(row.pos)}" oninput="editSpec(${i},'pos',this.value)"><input aria-label="Найменування ${i+1}" value="${safe(row.section||row.name)}" oninput="editSpec(${i},'${row.section?'section':'name'}',this.value)"><input aria-label="К-сть ${i+1}" placeholder="Кіл." value="${safe(row.qty)}" oninput="editSpec(${i},'qty',this.value)"><button aria-label="Видалити рядок" onclick="removeSpec(${i})">×</button></div>`).join('');}
function editSpec(i,key,value){project.specRows[i][key]=value;persist();drawDrawing()}
function addSpec(){project.specRows.push({section:'',pos:'',code:'',name:'Нова деталь',qty:'1',note:''});persist();drawSpecRows();drawDrawing()}
function addSpecGroup(){project.specRows.push({section:'Розділ',pos:'',code:'',name:'',qty:'',note:''});persist();drawSpecRows();drawDrawing()}
function removeSpec(i){project.specRows.splice(i,1);persist();drawSpecRows();drawDrawing()}
function exportModelShared(){const ps=meshForExport(),ext=$('fileType').value;if(!ps.length){status('Оберіть деталь',true);return;}const filename='AKKR5_'+(ps.length>1?'Reduktor_Assembly':fileBase(ps[0].name))+'.'+ext;const blob=ext==='stl'?stlBlob(ps):objBlob(ps);shareBlob(filename,ext==='stl'?'application/octet-stream':'text/plain',blob)}
function shareBlob(name,mime,blob){const reader=new FileReader();reader.onload=()=>{const b64=String(reader.result).split(',')[1];if(window.NativeApp&&NativeApp.shareFile){NativeApp.shareFile(name,mime,b64)}else save(name,mime,blob)};reader.readAsDataURL(blob)}
function shareSVG(){shareBlob('AKKR5_'+fileBase(currentName())+'.svg','image/svg+xml',new Blob([drawingSVG()],{type:'image/svg+xml;charset=utf-8'}))}
function shareCurrentPDF(){const svg=drawingSVG();if(window.NativeApp?.sharePdf){NativeApp.sharePdf(svg,'AKKR5_'+fileBase(currentName())+'.pdf');status('Створення PDF для надсилання…')}else printDrawing()}
function storeCurrentPDF(){const svg=drawingSVG();if(window.NativeApp?.savePdf){NativeApp.savePdf(svg,'AKKR5_'+fileBase(currentName())+'.pdf');status('Створення PDF…')}else printDrawing()}
function guardSharingInfo(){status('Відкриється меню Android: обери Telegram або інший додаток. Telegram має бути встановлений.')}
// Expose annotation tools in drawing pane, without disturbing the 3D engine.
const host=document.createElement('div');host.innerHTML=`<div class="card" id="cadTitleEditor">
<div class="cad-head"><h2>Редактор креслень · ЄСКД</h2><span class="cad-pill">Варіант 5</span></div>
<p class="cad-help">Редагуй ПІБ, групу, позначення, масштаб, матеріал і написи. Рамки: А3 420×297 мм; специфікація: А4 210×297 мм.</p>
<button class="cad-toggle" onclick="$('cadTitleFields').hidden=!$('cadTitleFields').hidden">▾ Редагувати рамку та основний напис</button>
<div id="cadTitleFields" hidden><div class="cad-form">
<label>Розробив<input id="cadAuthor" oninput="changeField('cadAuthor','author')"></label><label>Перевірив<input id="cadChecker" oninput="changeField('cadChecker','checker')"></label>
<label>Нормоконтроль<input id="cadNorm" oninput="changeField('cadNorm','controller')"></label><label>Затвердив<input id="cadApproved" oninput="changeField('cadApproved','approved')"></label>
<label>Група<input id="cadGroup" oninput="changeField('cadGroup','group')"></label><label>Навчальний заклад<input id="cadOrganization" oninput="changeField('cadOrganization','organization')"></label>
<label class="wide">Назва цього креслення<input id="cadName" oninput="changeSheetField('cadName','titles')"></label>
<label class="wide">Позначення цього аркуша<input id="cadCode" oninput="changeSheetField('cadCode','codes')"></label>
<label>Масштаб<input id="cadScale" oninput="changeField('cadScale','scale')"></label><label>Маса<input id="cadMass" oninput="changeField('cadMass','mass')"></label>
<label>Матеріал<input id="cadMaterial" oninput="changeField('cadMaterial','material')"></label><label>Літера<input id="cadLitera" oninput="changeField('cadLitera','litera')"></label>
<label class="wide">Префікс позначення<input id="cadPrefix" oninput="changeField('cadPrefix','codePrefix')"></label>
</div></div>
<hr class="cad-hr"/><strong>Інструменти редагування</strong><div class="cad-toolbar" id="cadDrawingTools">
<button data-cadtool="select" class="chosen" onclick="selectTool('select')">↖ Вибір</button><button data-cadtool="text" onclick="selectTool('text')">Текст</button><button data-cadtool="line" onclick="selectTool('line')">╱ Лінія</button><button data-cadtool="dim" onclick="selectTool('dim')">↔ Розмір</button><button data-cadtool="circle" onclick="selectTool('circle')">◯ Коло</button><button data-cadtool="rect" onclick="selectTool('rect')">▭ Прямокутник</button><button data-cadtool="erase" onclick="selectTool('erase')">⌫ Видалити</button></div>
<p class="cad-help" id="cadToolHint">Натисни на доданий елемент, щоб виділити; утримуй і переміщуй.</p>
<div class="row"><button onclick="undoDrawing()">↶ Скасувати</button><button onclick="redoDrawing()">↷ Повторити</button><button onclick="clearAnnotations()">Очистити позначки</button></div>
<div id="selectedProperties" class="cad-properties" hidden><strong id="selectedLabel">Виділений елемент</strong><label id="selectedTextBox" style="display:none;flex-direction:column">Текст<input id="selectedText" style="width:100%;padding:8px" onchange="updateSelectedText()"></label><div class="row"><button onclick="removeSelected()">Видалити вибране</button></div></div>
<div id="cadSpecRows" style="display:none"><hr class="cad-hr"/><h2>Редактор специфікації</h2><p class="cad-help">Колонки: позиція, найменування, кількість. Для повного позначення й примітки використовуй JSON-проєкт.</p><div id="cadSpecEditor"></div><div class="row" style="margin-top:8px"><button onclick="addSpec()">+ Деталь</button><button onclick="addSpecGroup()">+ Розділ</button></div></div>
<hr class="cad-hr"/><strong>Збереження / обмін</strong><div class="cad-save"><button class="primary" onclick="storeCurrentPDF()">⬇ PDF</button><button onclick="shareCurrentPDF()">↗ Поділитися PDF</button><button onclick="exportSVG()">⬇ SVG</button><button onclick="shareSVG()">↗ SVG</button><button onclick="saveProject()">⬇ Проєкт JSON</button></div>
<label class="cad-help">Відкрити раніше збережений JSON-проєкт: <input class="cad-file-input" type="file" accept=".json,application/json" onchange="loadProject(this.files[0]);this.value=''"/></label>
<p class="cad-footer-note">Штамп за ДСТУ ГОСТ 2.104:2006 (форма 1), формат за ГОСТ 2.301-68. Креслення навчальні, з умовними перерізами. Додані написи й розміри не є CAD-обмеженнями. Перед здачею перевір робочі розміри, допуски та правильність штрихування.</p>
</div>`;
const drawingBox=$('tab-draw').querySelector('.card');drawingBox.insertBefore(host.firstChild,$('drawing'));
$('drawing').classList.add('cad-canvas');
const exportCard=$('tab-export').querySelector('.card');const sharePanel=document.createElement('div');sharePanel.className='row';sharePanel.style.marginTop='10px';sharePanel.innerHTML=`<button class="primary" onclick="exportModelShared()">↗ Поділитися 3D-файлом</button><button onclick="saveProject()">⬇ Зберегти проєкт JSON</button>`;exportCard.appendChild(sharePanel);
const origSwitchTab=switchTab;switchTab=function(t){origSwitchTab(t);if(t==='draw'){drawSpecRows();refreshTitleFields()}};
const origFill=fillSelects;fillSelects=function(){origFill();drawSpecRows()};
const origRegenerate=regenerate;regenerate=function(){origRegenerate();persist()};
// Keep interactive HTML in sync when drawing selection changes.
$('drawingPart').addEventListener('change',()=>{selected=-1;drawSpecRows();refreshTitleFields();drawDrawing()});
refreshTitleFields();drawSpecRows();drawDrawing();persist();
