package com.cadviewer.mobile

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingSave: ByteArray? = null
    private var previewPrintWebView: WebView? = null
    private val CREATE_FILE = 1593

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 30)
        window.navigationBarColor = Color.rgb(10, 18, 30)
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(10, 18, 30))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true // read bundled application assets only
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.setSupportZoom(false)
            addJavascriptInterface(AndroidBridge(), "NativeApp")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url?.toString() ?: return true
                    return !uri.startsWith("file:///android_asset/")
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class AndroidBridge {
        @JavascriptInterface fun openViewer() {
            runOnUiThread { startActivity(Intent(this@MainActivity, ViewerActivity::class.java)) }
        }
        @JavascriptInterface fun shareReport(body: String) {
            runOnUiThread {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "АККР — варіант 5")
                    putExtra(Intent.EXTRA_TEXT, body.take(40000))
                }
                startActivity(Intent.createChooser(share, "Надіслати звіт"))
            }
        }
        /** Android Storage Access Framework: user chooses where an exported CAD file is saved. */
        @JavascriptInterface fun saveFile(name: String, mime: String, contentBase64: String) {
            try {
                require(name.length in 1..110 && !name.contains('/') && !name.contains('\\')) { "Invalid filename" }
                require(contentBase64.length < 20_000_000) { "File exceeds the size limit" }
                val bytes = Base64.decode(contentBase64, Base64.DEFAULT)
                runOnUiThread {
                    pendingSave = bytes
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = when (mime) {
                            "image/svg+xml" -> "image/svg+xml"
                            "text/plain" -> "text/plain"
                            else -> "application/octet-stream"
                        }
                        putExtra(Intent.EXTRA_TITLE, name)
                    }
                    startActivityForResult(intent, CREATE_FILE)
                }
            } catch (e: Exception) { runOnUiThread { toast("Export: " + (e.message ?: "unknown error")) } }
        }

        /** Opens Android Print UI, where Save as PDF is one of the print destinations. */
        @JavascriptInterface fun printDrawing(svg: String) {
            if (svg.length > 3_000_000 || !svg.trimStart().startsWith("<svg")) return
            runOnUiThread {
                previewPrintWebView?.destroy()
                val printView = WebView(this@MainActivity)
                previewPrintWebView = printView
                printView.settings.javaScriptEnabled = false
                printView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        manager.print("АККР5_креслення", printView.createPrintDocumentAdapter("АККР5_креслення"),
                            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A3).build())
                    }
                }
                val html = """<!doctype html><html><head><meta charset="utf-8"><style>
                    html,body{margin:0;padding:0;width:100%;height:100%;} svg{display:block;width:100%;height:auto;max-height:100%}
                    @page{size:A3 landscape;margin:0}
                    </style></head><body>$svg</body></html>"""
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
            }
        }

        @JavascriptInterface fun printAllDrawings(sheets: String) {
            if (sheets.length > 3_000_000 || !sheets.startsWith("<section class=\"sheet\">")) return
            runOnUiThread {
                previewPrintWebView?.destroy()
                val printView = WebView(this@MainActivity)
                previewPrintWebView = printView
                printView.settings.javaScriptEnabled = false
                printView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        manager.print("АККР5_повний_комплект", printView.createPrintDocumentAdapter("АККР5_повний_комплект"),
                            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A3).build())
                    }
                }
                val html = """<!doctype html><html><head><meta charset="utf-8"><style>
                    @page{size:A3 landscape;margin:0}html,body{margin:0;padding:0}
                    .sheet{width:420mm;height:297mm;break-after:page;page-break-after:always;overflow:hidden}
                    .sheet svg{width:420mm;height:297mm;display:block}
                    </style></head><body>$sheets</body></html>"""
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
            }
        }

        @JavascriptInterface fun copyText(body: String) {
            runOnUiThread {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("АККР", body.take(40000)))
            }
        }
    }

    @Deprecated("Legacy result callback retained for Android API 24+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_FILE) {
            val bytes = pendingSave
            pendingSave = null
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: throw IllegalStateException("Cannot open destination")
                    toast("CAD файл збережено")
                } catch (e: Exception) { toast("Не вдалося зберегти: " + e.message) }
            }
        }
    }

    private fun toast(text: String) = android.widget.Toast.makeText(this, text, android.widget.Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        previewPrintWebView?.destroy()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android; kept for API 24 compatibility")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
