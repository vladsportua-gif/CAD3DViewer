package com.cadviewer.mobile

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 30)
        window.navigationBarColor = Color.rgb(10, 18, 30)
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(10, 18, 30))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true // read bundled application assets only
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.setSupportZoom(false)
            addJavascriptInterface(AndroidBridge(), "NativeApp")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url?.toString() ?: return true
                    return !uri.startsWith("file:///android_asset/")
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class AndroidBridge {
        @JavascriptInterface fun openViewer() {
            runOnUiThread { startActivity(Intent(this@MainActivity, ViewerActivity::class.java)) }
        }
        @JavascriptInterface fun shareReport(body: String) {
            runOnUiThread {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "АККР — варіант 5")
                    putExtra(Intent.EXTRA_TEXT, body.take(40000))
                }
                startActivity(Intent.createChooser(share, "Надіслати звіт"))
            }
        }
        @JavascriptInterface fun copyText(body: String) {
            runOnUiThread {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("АККР", body.take(40000)))
            }
        }
    }

    @Deprecated("Deprecated in Android; kept for API 24 compatibility")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
