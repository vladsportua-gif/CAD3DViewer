package com.cadviewer.mobile

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import java.io.ByteArrayOutputStream
import java.io.File
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingSave: ByteArray? = null
    private var previewPrintWebView: WebView? = null
    private var pdfRenderView: WebView? = null
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val FILE_CHOOSE = 1594
    private val CREATE_FILE = 1593

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 30)
        window.navigationBarColor = Color.rgb(10, 18, 30)
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(10, 18, 30))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true // read bundled application assets only
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.setSupportZoom(false)
            addJavascriptInterface(AndroidBridge(), "NativeApp")
            webChromeClient = object: WebChromeClient() {
                override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                    uploadCallback?.onReceiveValue(null)
                    uploadCallback = filePathCallback
                    return try {
                        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "application/json"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }, FILE_CHOOSE)
                        true
                    } catch (_: Exception) {
                        uploadCallback = null
                        filePathCallback?.onReceiveValue(null)
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url?.toString() ?: return true
                    return !uri.startsWith("file:///android_asset/")
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class AndroidBridge {
        @JavascriptInterface fun openViewer() {
            runOnUiThread { startActivity(Intent(this@MainActivity, ViewerActivity::class.java)) }
        }
        @JavascriptInterface fun shareReport(body: String) {
            runOnUiThread {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "АККР — варіант 5")
                    putExtra(Intent.EXTRA_TEXT, body.take(40000))
                }
                startActivity(Intent.createChooser(share, "Надіслати звіт"))
            }
        }
        /** Android Storage Access Framework: user chooses where an exported CAD file is saved. */
        @JavascriptInterface fun saveFile(name: String, mime: String, contentBase64: String) {
            try {
                require(name.length in 1..110 && !name.contains('/') && !name.contains('\\')) { "Invalid filename" }
                require(contentBase64.length < 20_000_000) { "File exceeds the size limit" }
                val bytes = Base64.decode(contentBase64, Base64.DEFAULT)
                runOnUiThread {
                    pendingSave = bytes
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = when (mime) {
                            "image/svg+xml" -> "image/svg+xml"
                            "text/plain" -> "text/plain"
                            "application/json" -> "application/json"
                            "application/pdf" -> "application/pdf"
                            "application/zip" -> "application/zip"
                            else -> "application/octet-stream"
                        }
                        putExtra(Intent.EXTRA_TITLE, name)
                    }
                    startActivityForResult(intent, CREATE_FILE)
                }
            } catch (e: Exception) { runOnUiThread { toast("Export: " + (e.message ?: "unknown error")) } }
        }

        /** Opens Android Print UI, where Save as PDF is one of the print destinations. */
        @JavascriptInterface fun printDrawing(svg: String) {
            if (svg.length > 3_000_000 || !svg.trimStart().startsWith("<svg")) return
            runOnUiThread {
                previewPrintWebView?.destroy()
                val printView = WebView(this@MainActivity)
                previewPrintWebView = printView
                printView.settings.javaScriptEnabled = false
                printView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        manager.print("АККР5_креслення", printView.createPrintDocumentAdapter("АККР5_креслення"),
                            PrintAttributes.Builder().setMediaSize(if (svg.contains("width=\"210mm\"")) PrintAttributes.MediaSize.ISO_A4 else PrintAttributes.MediaSize.ISO_A3).build())
                    }
                }
                val html = """<!doctype html><html><head><meta charset="utf-8"><style>
                    html,body{margin:0;padding:0;width:100%;height:100%;} svg{display:block;width:100%;height:auto;max-height:100%}
                    @page{margin:0}
                    svg[width="210mm"]{width:210mm;height:297mm}
                    svg[width="420mm"]{width:420mm;height:297mm}
                    </style></head><body>$svg</body></html>"""
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
            }
        }

        @JavascriptInterface fun printAllDrawings(sheets: String) {
            if (sheets.length > 3_000_000 || !sheets.startsWith("<section class=\"sheet\">")) return
            runOnUiThread {
                previewPrintWebView?.destroy()
                val printView = WebView(this@MainActivity)
                previewPrintWebView = printView
                printView.settings.javaScriptEnabled = false
                printView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        manager.print("АККР5_повний_комплект", printView.createPrintDocumentAdapter("АККР5_повний_комплект"),
                            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A3).build())
                    }
                }
                val html = """<!doctype html><html><head><meta charset="utf-8"><style>
                    @page{size:A3 landscape;margin:0}html,body{margin:0;padding:0}
                    .sheet{width:420mm;height:297mm;break-after:page;page-break-after:always;overflow:hidden}
                    .sheet svg{width:420mm;height:297mm;display:block}
                    .sheet svg[width="210mm"]{width:210mm;height:297mm;margin:0 auto}
                    </style></head><body>$sheets</body></html>"""
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
            }
        }

        /** Shares STL/OBJ/SVG and project files with Telegram, Drive, Bluetooth, etc. */
        @JavascriptInterface fun shareFile(name: String, mime: String, contentBase64: String) {
            try {
                validateName(name)
                require(contentBase64.length <= 40_000_000) { "File too large" }
                val bytes = Base64.decode(contentBase64, Base64.DEFAULT)
                runOnUiThread { shareBytes(name, mime, bytes) }
            } catch (e: Exception) { runOnUiThread { toast("Надсилання: " + (e.message ?: "помилка")) } }
        }

        /** Raster-render an editable SVG sheet to a physical A3/A4 PDF for saving/sharing.
         * The Android Print menu remains available for higher-fidelity vector printing. */
        @JavascriptInterface fun sharePdf(svg: String, filename: String) {
            runOnUiThread { renderSvgPdf(svg, filename, true) }
        }
        @JavascriptInterface fun savePdf(svg: String, filename: String) {
            runOnUiThread { renderSvgPdf(svg, filename, false) }
        }

        @JavascriptInterface fun copyText(body: String) {
            runOnUiThread {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("АККР", body.take(40000)))
            }
        }
    }

    private fun validateName(name: String) {
        require(name.length in 1..100 && name != "." && name != ".." &&
          name.all { it.isLetterOrDigit() || it == '_' || it == '.' || it == '-' }) { "Недопустиме ім'я файлу" }
    }

    private fun shareBytes(filename: String, mime: String, bytes: ByteArray) {
        try {
            validateName(filename)
            require(bytes.size <= 35_000_000)
            val base = File(cacheDir, "shared").apply { mkdirs() }
            val f = File(base, filename)
            f.writeBytes(bytes)
            val uri = Uri.Builder().scheme("content").authority("$packageName.share").appendPath(filename).build()
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(contentResolver, "АККР CAD файл", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(sendIntent, "Поділитися файлом через…"))
        } catch (e: Exception) { toast("Неможливо поділитися: " + e.message) }
    }

    private fun startSaveBytes(name: String, mime: String, bytes: ByteArray) {
        pendingSave = bytes
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, CREATE_FILE)
    }

    private fun renderSvgPdf(svg: String, filename: String, share: Boolean) {
        if (svg.length > 3_000_000 || !svg.trimStart().startsWith("<svg")) {
            toast("Некоректний файл креслення")
            return
        }
        try {
            validateName(filename)
            pdfRenderView?.destroy()
            val a4 = svg.contains("width=\"210mm\"")
            // A3 landscape 420x297 mm or A4 portrait 210x297 mm, points (1/72 inch).
            val pageW = if (a4) 595 else 1191
            val pageH = 842
            val renderW = if (a4) 1488 else 2400
            val renderH = if (a4) 2105 else 1697
            val target = WebView(this)
            pdfRenderView = target
            target.settings.javaScriptEnabled = false
            target.setBackgroundColor(Color.WHITE)
            target.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    target.postDelayed({
                        try {
                            target.measure(View.MeasureSpec.makeMeasureSpec(renderW, View.MeasureSpec.EXACTLY),
                                View.MeasureSpec.makeMeasureSpec(renderH, View.MeasureSpec.EXACTLY))
                            target.layout(0, 0, renderW, renderH)
                            val bitmap = Bitmap.createBitmap(renderW, renderH, Bitmap.Config.ARGB_8888)
                            val bitmapCanvas = Canvas(bitmap)
                            bitmapCanvas.drawColor(Color.WHITE)
                            target.draw(bitmapCanvas)
                            val pdf = PdfDocument()
                            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
                            page.canvas.drawColor(Color.WHITE)
                            page.canvas.drawBitmap(bitmap, null, Rect(0, 0, pageW, pageH), Paint(Paint.FILTER_BITMAP_FLAG))
                            pdf.finishPage(page)
                            val stream = ByteArrayOutputStream()
                            pdf.writeTo(stream)
                            pdf.close()
                            bitmap.recycle()
                            if (share) shareBytes(filename, "application/pdf", stream.toByteArray())
                            else startSaveBytes(filename, "application/pdf", stream.toByteArray())
                        } catch (e: Exception) { toast("PDF: " + e.message) }
                        finally { if (pdfRenderView === target) pdfRenderView = null; target.destroy() }
                    }, 450L)
                }
            }
            val html = """<!DOCTYPE html><html><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
              <style>html,body{padding:0;margin:0;background:white;overflow:hidden;}svg{width:100%;height:100%;display:block}</style></head>
              <body style="width:${renderW}px;height:${renderH}px;">$svg</body></html>"""
            target.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
        } catch (e: Exception) { toast("PDF: " + e.message) }
    }

    @Deprecated("Legacy result callback retained for Android API 24+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSE) {
            val callback = uploadCallback
            uploadCallback = null
            callback?.onReceiveValue(if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null)
        }
        if (requestCode == CREATE_FILE) {
            val bytes = pendingSave
            pendingSave = null
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: throw IllegalStateException("Cannot open destination")
                    toast("CAD файл збережено")
                } catch (e: Exception) { toast("Не вдалося зберегти: " + e.message) }
            }
        }
    }

    private fun toast(text: String) = android.widget.Toast.makeText(this, text, android.widget.Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        previewPrintWebView?.destroy()
        pdfRenderView?.destroy()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android; kept for API 24 compatibility")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
